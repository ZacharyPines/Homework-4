package Application;
import java.sql.*;

/**
 * Represents an answer to a question in the application.
 * Stores metadata including the ID, associated question ID, answer text, and creation timestamp.
 */
public class Answer {
    private int id;
    private int questionId;
    private String text;
    private Timestamp createdAt;

    /**
     * Constructs an Answer object with specified values.
     *
     * @param id the unique identifier for the answer
     * @param questionId the ID of the question this answer is related to
     * @param text the content of the answer
     * @param createdAt the timestamp when the answer was created
     */
    public Answer(int id, int questionId, String text, Timestamp createdAt) {
        this.id = id;
        this.questionId = questionId;
        this.text = text;
        this.createdAt = createdAt;
    }

    /**
     * Returns the text content of the answer.
     *
     * @return the answer text
     */
    public String getText() {
        return text;
    }
}
