package Application;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages the connection to the database, and performs user,
 * question, answer, and flagging operations
 */

public class DatabaseHelper {

    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "org.h2.Driver";
    public static String DB_URL = "jdbc:h2:~/FoundationDatabase";

    // Database credentials
    static final String USER = "sa";
    static final String PASS = "";

    private Connection connection = null;
    private Statement statement = null;

    /**
     * Connects to the database
     *
     * @throws SQLException if database connection fails
     */
    public void connectToDatabase() throws SQLException {
        connectToDatabase(false);
    }

    /**
     * Connects to the database, and creates tables if none exist
     *
     * @param Clear whether to drop existing database objects
     * @throws SQLException if connection fails
     */
    public void connectToDatabase(Boolean Clear) throws SQLException {
        try {
            Class.forName(JDBC_DRIVER); // Load the JDBC driver
            System.out.println("Connecting to database...");
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            statement = connection.createStatement();

            if(Clear) {
                statement.execute("DROP ALL OBJECTS");
            }

            createTables(); // Create tables if they don't exist
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
        }
    }

    private void createTables() throws SQLException {
        String questionsTable = "CREATE TABLE IF NOT EXISTS Questions (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "questionText VARCHAR(500), " +
                "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
        statement.execute(questionsTable);

        String answersTable = "CREATE TABLE IF NOT EXISTS Answers (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "questionId INT, " +
                "answerText VARCHAR(500), " +
                "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY (questionId) REFERENCES Questions(id) ON DELETE CASCADE)";
        statement.execute(answersTable);

        String flagsTable = "CREATE TABLE IF NOT EXISTS Flags (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "questionId INT, " +
                "isFlagged BOOLEAN DEFAULT TRUE, " +
                "createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY (questionId) REFERENCES Questions(id) ON DELETE CASCADE)";
        statement.execute(flagsTable);
    }

    /**
     * Adds a question to the database.
     *
     * @param questionText the content of the question to be added
     * @throws SQLException if insertion fails
     */
    public void addQuestion(String questionText) throws SQLException {
        String query = "INSERT INTO Questions (questionText) VALUES (?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, questionText);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding question");
        }
    }

    /**
     * Adds an answer for a specific question to the database.
     *
     * @param questionId the ID of the question being answered
     * @param answerText the text of the answer
     * @throws SQLException if insertion fails
     */
    public void addAnswer(int questionId, String answerText) throws SQLException {
        String query = "INSERT INTO Answers (questionId, answerText) VALUES (?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.setString(2, answerText);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error adding answer");
        }
    }

    /**
     * Retrieves all questions stored in the database.
     *
     * @return a list of all Question objects
     */
    public List<Question> getAllQuestions() {
        List<Question> questions = new ArrayList<>();
        String query = "SELECT id, questionText, createdAt FROM Questions";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String text = rs.getString("questionText");
                Timestamp createdAt = rs.getTimestamp("createdAt");
                questions.add(new Question(id, text, createdAt));
            }
        } catch (SQLException e) {
            System.out.println("Error getting questions");
        }
        return questions;
    }

    /**
     * Retrieves all answers for a given question.
     *
     * @param questionId the ID of the question
     * @return a list of Answer objects related to the question
     */
    public List<Answer> getAnswersForQuestion(int questionId) {
        List<Answer> answers = new ArrayList<>();
        String query = "SELECT id, answerText, createdAt FROM Answers WHERE questionId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String text = rs.getString("answerText");
                Timestamp createdAt = rs.getTimestamp("createdAt");
                answers.add(new Answer(id, questionId, text, createdAt));
            }
        } catch (SQLException e) {
            System.out.println("Error getting answers");
        }
        return answers;
    }

    /**
     * Counts the number of answers associated with a specific question.
     *
     * @param questionId the ID of the question
     * @return number of answers for the question
     */
    public int getAnswerCount(int questionId) {
        String query = "SELECT COUNT(*) AS count FROM Answers WHERE questionId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("count");
            }
        } catch (SQLException e) {
            System.out.println("Error getting answer count");
        }
        return 0;
    }

    /**
     * Flags a question for review.
     *
     * @param questionId the ID of the question to flag
     */
    public void flagQuestion(int questionId) {
        String query = "INSERT INTO Flags (questionId, isFlagged) VALUES (?, TRUE)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
            System.out.println("Question has been flagged.");
        } catch (SQLException e) {
            System.out.println("Error flagging question");
        }
    }

    /**
     * Retrieves all flagged questions.
     *
     * @return a list of flagged Question objects
     */
    public List<Question> getAllFlaggedQuestions() {
        List<Question> flaggedQuestions = new ArrayList<>();
        String query = "SELECT Q.id, Q.questionText, Q.createdAt FROM Questions Q " +
                "JOIN Flags F ON Q.id = F.questionId WHERE F.isFlagged = TRUE";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String text = rs.getString("questionText");
                Timestamp createdAt = rs.getTimestamp("createdAt");
                flaggedQuestions.add(new Question(id, text, createdAt));
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving flagged questions");
        }
        return flaggedQuestions;
    }

    /**
     * Removes the flag from a question.
     *
     * @param questionId the ID of the question to unflag
     */
    public void unflagQuestion(int questionId) {
        String query = "UPDATE Flags SET isFlagged = FALSE WHERE questionId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
            System.out.println("Flag removed from question.");
        } catch (SQLException e) {
            System.out.println("Error unflagging question");
        }
    }

    /**
     * Deletes a question from the database.
     *
     * @param questionId the ID of the question to delete
     */
    public void deleteQuestion(int questionId) {
        String query = "DELETE FROM Questions WHERE id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, questionId);
            pstmt.executeUpdate();
            System.out.println("Question deleted from database.");
        } catch (SQLException e) {
            System.out.println("Error deleting question");
        }
    }

    /**
     * Closes the database connection and resources.
     */
    public void closeConnection() {
        try{
            if(statement != null) statement.close();
        } catch(SQLException e) {
            System.out.println("Error closing connection");;
        }
    }
}
