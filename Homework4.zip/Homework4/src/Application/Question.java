package Application;
import java.sql.*;

/**
 * Represents a question in the application.
 * Contains the question ID, text, and creation timestamp.
 */
public class Question {
    private int id;
    private String text;
    private Timestamp createdAt;

    /**
     * Constructs a Question object with the given parameters.
     *
     * @param id the unique identifier for the question
     * @param text the content of the question
     * @param createdAt the timestamp when the question was created
     */
    public Question(int id, String text, Timestamp createdAt) {
        this.id = id;
        this.text = text;
        this.createdAt = createdAt;
    }

    /**
     * Returns the unique ID of the question.
     *
     * @return the question ID
     */
    public int getId() {
        return id;
    }

    /**
     * Returns the text of the question.
     *
     * @return the question text
     */
    public String getText() {
        return text;
    }
}
