package Application;

import java.util.List;
import java.util.Scanner;

/**
 * Main class to run the application.
 * Provides a console interface for users to submit questions, answer them, and for staff to moderate questions.
 */
public class Main {
    /**
     * User forward part of the application
     *
     * @param args numbers sent in command line
     */
    public static void main(String[] args) {

        // Create Database and Scanner
        DatabaseHelper dbHelper = new DatabaseHelper();
        Scanner scanner = new Scanner(System.in);

        boolean run = true;

        try {
            dbHelper.connectToDatabase();
        } catch (Exception e) {
            System.out.println("Couldn't connect to database");
            run = false;
        }

        while (run) {

            System.out.println("Press 1 to ask a question. Press 2 to see all questions. Press 3 for staff commands. Press 0 to exit.");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {

                try {
                    System.out.println("Enter your question:");
                    String questionText = scanner.nextLine();
                    dbHelper.addQuestion(questionText);
                    System.out.println("Your question has been added");
                } catch (Exception e) {
                    System.out.println("Couldn't add question");
                }

            } else if (choice == 2) {

                List<Question> questions = dbHelper.getAllQuestions();
                if (questions.size() == 0) {
                    System.out.println("No questions");
                    continue;
                }

                for (int i = 0; i < questions.size(); i++) {
                    Question q = questions.get(i);
                    int answerCount = dbHelper.getAnswerCount(q.getId());
                    System.out.printf("%d. %s [%d]\n", (i + 1), q.getText(), answerCount);
                }

                System.out.println("Press the number of a question to view. Press 0 to go back:");
                int questionChoice = scanner.nextInt();
                scanner.nextLine();

                if (questionChoice == 0) {
                    continue;
                }

                if (questionChoice < 1 || questions.size() < questionChoice) {
                    System.out.println("Invalid choice");
                    continue;
                }

                Question selectedQuestion = questions.get(questionChoice - 1);
                int selectedQuestionId = selectedQuestion.getId();

                while (true) {
                    System.out.println("Press 1 to view answers. Press 2 to answer this question. Press 0 to go back");
                    choice = scanner.nextInt();
                    scanner.nextLine();

                    if (choice == 1) {
                        List<Answer> answers = dbHelper.getAnswersForQuestion(selectedQuestionId);
                        if (answers.isEmpty()) {
                            System.out.println("No answers");
                        } else {
                            for (int i = 0; i < answers.size(); i++) {
                                Answer a = answers.get(i);
                                System.out.println("- " + a.getText());
                            }

                        }

                    } else if (choice == 2) {

                        try {
                            System.out.println("Enter your answer:");
                            String answerText = scanner.nextLine();
                            dbHelper.addAnswer(selectedQuestionId, answerText);
                            System.out.println("Your answer has been added.");
                        } catch (Exception e) {
                            System.out.println("Couldn't add answer");
                        }

                    } else if (choice == 0) {
                        break;
                    }

                    else {
                        System.out.println("Invalid choice");
                    }
                }

            } else if (choice == 3) {
                while (true) {
                    System.out.println("\nPress 1 to list all questions. Press 2 to flag a question. Press 3 to view flagged questions. Press 4 to unflag. Press 5 to delete a flagged question. Press 0 to go back.");


                    int staffChoice = scanner.nextInt();
                    scanner.nextLine();

                    if (staffChoice == 1) {
                        List<Question> questions = dbHelper.getAllQuestions();
                        if (questions.isEmpty()) {
                            System.out.println("No questions found.");
                        } else {
                            for (Question q : questions) {
                                System.out.printf("ID: %d - %s\n", q.getId(), q.getText());
                            }
                        }

                    } else if (staffChoice == 2) {
                        List<Question> questions = dbHelper.getAllQuestions();
                        if (questions.isEmpty()) {
                            System.out.println("No questions to flag.");
                        } else {
                            for (Question q : questions) {
                                System.out.printf("ID: %d | %s\n", q.getId(), q.getText());
                            }
                            System.out.print("Enter the ID of the question to flag (0 to cancel): ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            if (id != 0) {
                                dbHelper.flagQuestion(id);
                            }
                        }

                    } else if (staffChoice == 3) {
                        List<Question> flagged = dbHelper.getAllFlaggedQuestions();
                        if (flagged.isEmpty()) {
                            System.out.println("No flagged questions.");
                        } else {
                            for (Question q : flagged) {
                                System.out.printf("ID: %d | %s\n", q.getId(), q.getText());
                            }
                        }

                    } else if (staffChoice == 4) {
                        List<Question> flagged = dbHelper.getAllFlaggedQuestions();
                        if (flagged.isEmpty()) {
                            System.out.println("No flagged questions.");
                        } else {
                            for (Question q : flagged) {
                                System.out.printf("ID: %d | %s\n", q.getId(), q.getText());
                            }
                            System.out.print("Enter the ID to unflag (0 to cancel): ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            if (id != 0) {
                                dbHelper.unflagQuestion(id);
                            }
                        }

                    } else if (staffChoice == 5) {
                        List<Question> flagged = dbHelper.getAllFlaggedQuestions();
                        if (flagged.isEmpty()) {
                            System.out.println("No flagged questions.");
                        } else {
                            for (Question q : flagged) {
                                System.out.printf("ID: %d | %s\n", q.getId(), q.getText());
                            }
                            System.out.print("Enter the ID to delete (0 to cancel): ");
                            int id = scanner.nextInt();
                            scanner.nextLine();
                            if (id != 0) {
                                dbHelper.deleteQuestion(id);
                            }
                        }

                    } else if (staffChoice == 0) {
                        break;

                    } else {
                        System.out.println("Invalid choice");
                    }
                }

            } else if (choice == 0) {
                run = false;
                System.out.println("Thank you!");

            } else {
                System.out.println("Invalid choice");
            }
        }

        dbHelper.closeConnection();
        scanner.close();

    }
}
